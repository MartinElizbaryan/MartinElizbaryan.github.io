$(document).ready(function(){
	$(document).keydown(function(e){
        if(e.key== "Q"){
           $(location).attr('href', "index.php");
        }
    })
})